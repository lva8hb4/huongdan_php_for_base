<?php
//Khai báo lớp để sử dụng
include_once 'SachBusiness.php';

//Khai báo đối tượng
$bus = new SachBusiness();

//Lấy danh sách
$danhSach = $bus->layDanhSach();
?>
<html>
<head>
    <title>Quản lý thông tin sách</title>
</head>
<body>
<div style="width:100%; text-align:center;">
    <h1>Quản lý thông tin sách</h1>
</div>
<div style="width:100%; text-align:right;">
    <a href="SachAdd.php">Thêm mới</a>
</div>
<table border="1" style="width:100%; border-collapse: collapse;">
    <tr>
        <th>Ảnh</th>
        <th>Id</th>
        <th>Tên sách</th>
        <th>Mô tả</th>
        <th>Giá sách</th>
        <th>Ngày tạo</th>
        <th>Tác giả</th>
        <th></th>
    </tr>
    <?php
        foreach($danhSach as $sach){ ?>
    <tr>
        <td><?php echo $sach->anhSach ?></td>
        <td><?php echo $sach->sachId ?></td>
        <td><?php echo $sach->tenSach ?></td>
        <td><?php echo $sach->moTa ?></td>
        <td><?php echo $sach->giaSach ?></td>
        <td><?php echo $sach->ngayTao ?></td>
        <td><?php echo $sach->tacGia ?></td>
        <td>
            <a href="SachAdd.php?sachId=<?php echo $sach->sachId?>">Sửa</a>
        </td>
    </tr>
    <?php }?>
</table>
</body>
</html>
