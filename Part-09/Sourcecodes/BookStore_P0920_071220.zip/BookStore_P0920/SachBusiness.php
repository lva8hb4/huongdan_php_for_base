<?php

//Khai báo lớp sử dụng
include_once 'DataProvider.php';
include_once 'Sach.php';
class SachBusiness extends DataProvider
{
    /**
     * Hàm lấy danh sách sách trong db
     * @return Danh sách các thông tin sách
     */
    public function layDanhSach()
    {
        //Khai báo 1 danh sách chứa dữ liệu sách lấy được
        $arrSach = Array();

        //Lấy đối tượng kết nối đến db
        $conn = $this->ketNoi();

        //Khai báo câu lệnh truy vấn để lấy thông tin
        $strSQL = "Select SachId, TenSach, MoTa, AnhSach, NgayTao, GiaSach, TacGia, MaChuDe from Sach";
        //Lấy danh sách sách từ db
        $ketQua = mysqli_query($conn, $strSQL);

        //Đọc từng dòng để đưa vào danh sách
        while($row = mysqli_fetch_array($ketQua))
        {
            //Khai báo 1 đối tượng sách
            $sach = new Sach();
            $sach->sachId = $row['SachId'];
            $sach->tenSach = $row['TenSach'];
            $sach->moTa = $row['MoTa'];
            $sach->anhSach = $row['AnhSach'];
            $sach->ngayTao = $row['NgayTao'];
            $sach->giaSach = $row['GiaSach'];
            $sach->tacGia = $row['TacGia'];
            $sach->maChuDe = $row['MaChuDe'];
            //Thêm vào danh sách
            array_push($arrSach, $sach);
        }

        //Đóng kết nối
        $conn->close();

        return $arrSach;
    }//End danh sách

    /**
     * Hàm lấy thông tin chi tiết sách theo mã sách
     * @param $maSach: Mã sách cần lấy thông tin chi tiết
     * @return Sach|Đối tượng sách lấy được
     */
    public function layChiTietSach($maSach)
    {
        //Khai báo 1 đối tượng sách
        $sach = null;

        //Lấy đối tượng kết nối đến db
        $conn = $this->ketNoi();

        //Khai báo câu lệnh truy vấn để lấy thông tin
        $strSQL = "Select SachId, TenSach, MoTa, AnhSach, NgayTao, GiaSach, TacGia, MaChuDe from Sach where SachId = " . $maSach;

        print_r($strSQL);
        //Lấy danh sách sách từ db
        $ketQua = mysqli_query($conn, $strSQL);

        //Đọc từng dòng để lấy thông tin cho đối tượng sách
        while($row = mysqli_fetch_array($ketQua))
        {
            //Khai báo 1 đối tượng sách
            $sach = new Sach();
            $sach->sachId = $row['SachId'];
            $sach->tenSach = $row['TenSach'];
            $sach->moTa = $row['MoTa'];
            $sach->anhSach = $row['AnhSach'];
            $sach->ngayTao = $row['NgayTao'];
            $sach->giaSach = $row['GiaSach'];
            $sach->tacGia = $row['TacGia'];
            $sach->maChuDe = $row['MaChuDe'];
        }

        //Đóng kết nối
        $conn->close();

        return $sach;
    }//End thông tin sách chi tiết

    /**
     * Hàm thực hiện thêm mới thông tin sách
     * @param $sach, Đối tượng sách cần thêm
     * @return bool, True nếu thành công, False nếu thất bại
     */
    public function themMoi($sach)
    {
        //Lấy đối tượng kết nối đến db
        $conn = $this->ketNoi();

        //Khai báo câu lệnh insert
        $strInsert = "Insert Into Sach(TenSach, MoTa, AnhSach, TacGia, NgayTao, GiaSach, MaChuDe) values(?,?,?,?,NOW(),?,?)";

        //Khai báo và biên dịch câu lệnh
        $comm = $conn->prepare($strInsert);
        //Gán các giá trị cho các tham số
        $comm->bind_param("ssssds", $sach->tenSach, $sach->moTa, $sach->anhSach, $sach->tacGia, $sach->giaSach, $sach->maChuDe);

        //Thực hiện công việc
        $ketQua = $comm->execute();

        //Đóng kết nối
        $comm->close();
        $conn->close();

        if($ketQua)
        {
            return true;
        }

        return false;
    }

    /**
     * Hàm cập nhật thông tin sách
     * @param $sach, Đối tượng sách cần cập nhật
     * @return bool, True nếu thành công, False nếu thất bại
     */
    public function capNhat($sach)
    {
        //Lấy đối tượng kết nối đến db
        $conn = $this->ketNoi();

        //Khai báo câu lệnh cập nhật
        $strUpdate = "Update Sach set TenSach=?, MoTa=?, AnhSach=?, TacGia=?, GiaSach=?, MaChuDe=? where SachId=?";

        //Khai báo và biên dịch câu lệnh
        $comm = $conn->prepare($strUpdate);
        //Gán các giá trị cho các tham số
        $comm->bind_param("ssssdsd", $sach->tenSach, $sach->moTa, $sach->anhSach, $sach->tacGia, $sach->giaSach, $sach->maChuDe, $sach->maSach);

        //Thực hiện công việc
        $ketQua = $comm->execute();

        //Đóng kết nối
        $comm->close();
        $conn->close();

        if($ketQua)
        {
            return true;
        }

        return false;
    }

    /**
     * Hàm xoá thông tin sách
     * @param $maSach, mã sách cần xoá thông tin
     * @return bool True nếu xoá thành công, False nếu thất bại
     */
    public function xoa($maSach)
    {
        //Lấy đối tượng kết nối đến db
        $conn = $this->ketNoi();

        //Khai báo câu lệnh xoá
        $strDelete = "Delete from Sach where SachId=?";

        //Khai báo và biên dịch câu lệnh
        $comm = $conn->prepare($strDelete);
        //Gán các giá trị cho các tham số
        $comm->bind_param("d",$maSach);

        //Thực hiện công việc
        $ketQua = $comm->execute();

        //Đóng kết nối
        $comm->close();
        $conn->close();

        if($ketQua)
        {
            return true;
        }

        return false;
    }
}