<?php
//Xử lý thêm mới, hiển thị chi tiết và cập nhật sách
//Khai báo các lớp sử dụng
include_once 'Sach.php';
include_once 'SachBusiness.php';

//Khai báo biến
$thongBao = "";
$maSach = 0;
$tenSach = ""; $moTa = ""; $anhSach = ""; $tacGia = ""; $giaSach = 0;
$maChuDe = "";
$sach = null;

//Khai báo 1 đối tượng
$bus = new SachBusiness();

//Lấy sách id trong TH sửa
if(isset($_REQUEST['sachId']))
{
    $maSach = $_GET['sachId'];

    //Lấy chi tiết thông tin sách
    $sach = $bus->layChiTietSach($maSach);

    if($sach != null)
    {
        $tenSach = $sach->tenSach;
        $moTa = $sach->moTa;
        $anhSach = $sach->anhSach;
        $tacGia = $sach->tacGia;
        $maChuDe = $sach->maChuDe;
        $giaSach = $sach->giaSach;
    }
}
//Nếu người dùng nhấn nút cập nhật
if(isset($_REQUEST['btnCapNhat']))
{
    //Lấy thông tin từ trên giao diện
    $maSach = intval($_POST['maSach']);
    $tenSach = $_POST['txtTenSach'];
    $moTa = $_POST['txtMoTa'];
    $tacGia = $_POST['txtTacGia'];
    $giaSach = floatval($_POST['txtGiaSach']);
    $maChuDe = $_POST['chuDe'];

    //Xử lý upload ảnh
    if($_FILES['fUpload']['error'] > 0)
    {
        echo "Có lỗi xảy ra trong quá trình tải file. Chi tiết: " . $_FILES['fUpload']['error']. "<br>";
    }
    else
    {
        echo "Tên file: " . $_FILES['fUpload']['name'] . "<br>";
        echo "Kiểu file: " . $_FILES['fUpload']['type'] . "<br>";
        echo "Kích thước: " . $_FILES['fUpload']['size'] . "<br>";
        echo "Thư mục tạm: " . $_FILES['fUpload']['tmp_name'] . "<br>";

        //Di chuyển file vào thư mục của dự án
        move_uploaded_file($_FILES['fUpload']['tmp_name'], "images/" . $_FILES['fUpload']['name']);
        echo "Thực hiện tải file thành công !<br>";
        $anhSach =  $_FILES['fUpload']['name'];
    }

    //Tạo đối tượng sách
    $sach = new Sach();
    //Gán thông tin vào đối tượng
    $sach->tenSach = $tenSach;
    $sach->moTa = $moTa;
    $sach->anhSach = $anhSach;
    $sach->giaSach = $giaSach;
    $sach->tacGia = $tacGia;
    $sach->maChuDe = $maChuDe;

    $ketQua = false;
    if($maSach > 0)
    {
        $sach->sachId = $maSach;
        //Cập nhật
        $ketQua = $bus->capNhat($sach);
    }
    else
    {
        //Thêm mới
        $ketQua = $bus->themMoi($sach);
    }

    if($ketQua)
    {
        $thongBao = "Cập nhật thông tin sách thành công";
    }
}
?>
<html>
<head>
    <title>Thêm thông tin sách</title>
</head>
<body>
<form method="post" enctype="multipart/form-data">
    <fieldset>
        <legend>Nhập thông tin sách</legend>
        <div>
            <label>Tên sách</label>
            <div>
                <input type="text" name="txtTenSach" value="<?php echo $tenSach?>"/>
                <input type="hidden" name="maSach" value="<?php echo $maSach ?>">
            </div>
        </div>
        <br>
        <div>
            <label>Mô tả</label>
            <div>
                <textarea name="txtMoTa" rows="5"><?php echo $moTa?></textarea>
            </div>
        </div>
        <div>
            <label>Ảnh sách</label>
            <div>
                <input type="file" name="fUpload"/>
            </div>
        </div>
        <br>
        <div>
            <label>Giá sách</label>
            <div>
                <input type="text" name="txtGiaSach" value="<?php echo $giaSach?>"/>
            </div>
        </div>
        <br>
        <div>
            <label>Tác giả</label>
            <div>
                <input type="text" name="txtTacGia" value="<?php echo $tacGia
                ?>"/>
            </div>
        </div>
        <br>
        <!--Xử lý hiển thị combobox chủ đề-->
        <div>
            <label>Chủ đề</label>
            <div>
                <?php
                //Khai báo lớp
                include_once 'ChuDeBusiness.php';
                //Khai báo đối tượng
                $bus = new ChuDeBusiness();

                $lstChuDe = $bus->layDanhSach();
                ?>
                <select name="chuDe">
                    <?php foreach($lstChuDe as $cd){
                        //Nếu thông tin chủ đề trong combobox trùng với mã chủ đề của sách
                        //thì thêm thuộc selected để chọn hiển thị thông tin đó trong combox
                        if($cd->maChuDe == $maChuDe){
                        ?>
                        <option selected="selected" value="<?php echo $cd->maChuDe ?>">
                            <?php echo $cd->tenChuDe ?>
                        </option>
                    <?php } else { ?>
                    <option value="<?php echo $cd->maChuDe ?>">
                        <?php echo $cd->tenChuDe ?>
                    </option>
                    <?php }} ?>
                </select>
            </div>
        </div>
        <br>
        <div>
            <label></label>
            <div>
                <input type="submit" name="btnCapNhat" value="Cập nhật"/>
                &nbsp;
                <a href="QuanLySach.php" title="Trở về trang danh sách">Trở về</a>
            </div>
        </div>
        <div>
            <label></label>
            <div>
                    <?php echo $thongBao?>
            </div>
        </div>
    </fieldset>

</form>
</body>
</html>
