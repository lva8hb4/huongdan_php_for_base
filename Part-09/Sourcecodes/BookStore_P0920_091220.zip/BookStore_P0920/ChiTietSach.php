<?php
//Khai báo lớp
include_once 'SachBusiness.php';

//Khai báo đối tượng
$bus = new SachBusiness();

$sachId = 0;
$tenSach = ""; $moTa = ""; $giaSach = 0;
$tacGia = ""; $anhSach = "";
if(isset($_REQUEST['sachId']))
{
    $sachId = intval($_GET['sachId']);

    $sach = $bus->layChiTietSach($sachId);

    if($sach != null)
    {
        $tenSach = $sach->tenSach;
        $moTa = $sach->moTa;
        $tacGia = $sach->tacGia;
        $giaSach = $sach->giaSach;
        $anhSach = $sach->anhSach;
    }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Book Store Template, Stanford - Day lap trinh</title>
    <meta name="keywords" content="Book Store Template, Stanford - Day lap trinh" />
    <meta name="description" content="Book Store Template, Stanford - Day lap trinh" />
    <link href="templatemo_style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<!-- Templates from www.stanford.com.vn -->
<div id="templatemo_container">
    <?php
    include_once 'layout/menu.php';
    include_once 'layout/header.php';
    ?>

    <div id="templatemo_content">

        <div id="templatemo_content_left">
            <?php
            include_once 'layout/sidebar.php'; ?>
        </div> <!-- end of content left -->

        <div id="templatemo_content_right">
            <h1><?php echo $tenSach ?><span>(by <?php echo $tacGia ?>)</span></h1>
            <div style="width:100%; text-align:right;">
            <h2>Giá bán: <?php echo number_format($giaSach) ?> đồng</h2>
            </div>
            <div class="image_panel"><img src="images/<?php echo $anhSach ?>" alt="CSS Template" width="100" height="150" /></div>
            <h2><?php echo $moTa ?></h2>

            <a href="subpage.html"><img src="images/templatemo_ads.jpg" alt="ads" /></a>
        </div> <!-- end of content right -->

        <div class="cleaner_with_height">&nbsp;</div>
    </div> <!-- end of content -->

    <?php
    include_once 'layout/footer.php';
    ?>
</div> <!-- end of container -->
<div align=center>This template  downloaded form <a href='http://www.stanford.com.vn'>Stanford.com.vn</a></div></body>
</html>
