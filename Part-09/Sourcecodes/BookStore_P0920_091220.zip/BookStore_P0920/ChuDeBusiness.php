<?php

//Khai báo lớp
include_once 'DataProvider.php';
include_once 'ChuDe.php';

class ChuDeBusiness extends DataProvider
{
    /**
     * Hàm lấy danh sách chủ đề
     * @return array
     */
    public function layDanhSach()
    {
        //Khai báo 1 danh sách chứa dữ liệu sách lấy được
        $arrChuDe = Array();

        //Lấy đối tượng kết nối đến db
        $conn = $this->ketNoi();

        //Khai báo câu lệnh truy vấn để lấy thông tin
        $strSQL = "Select MaChuDe, TenChuDe, MoTa from ChuDe";
        //Lấy danh sách chủ đề từ db
        $ketQua = mysqli_query($conn, $strSQL);

        //Đọc từng dòng để đưa vào danh sách
        while($row = mysqli_fetch_array($ketQua))
        {
            //Khai báo 1 đối tượng sách
            $chuDe = new ChuDe();
            $chuDe->maChuDe = $row['MaChuDe'];
            $chuDe->tenChuDe = $row['TenChuDe'];
            $chuDe->moTa = $row['MoTa'];

            //Thêm vào danh sách
            array_push($arrChuDe, $chuDe);
        }

        //Đóng kết nối
        $conn->close();

        return $arrChuDe;
    }//End danh sách
}