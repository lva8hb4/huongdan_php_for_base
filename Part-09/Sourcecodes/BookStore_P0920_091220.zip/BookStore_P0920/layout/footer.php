<div id="templatemo_footer">

    <a href="subpage.html">Home</a> | <a href="subpage.html">Search</a> | <a href="subpage.html">Books</a> | <a href="#">New Releases</a> | <a href="#">FAQs</a> | <a href="#">Contact Us</a><br />
    Copyright © 2020 <a href="https://stanford.com.vn"><strong>Stanford - Day kinh nghiem lap trinh</strong></a>
</div>