<?php
//Khai báo lớp
include_once 'SachBusiness.php';

//Khai báo đối tượng
$bus = new SachBusiness();

//Lấy danh sách
$danhSach = $bus->layDanhSach();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Book Store Template, Stanford - Day lap trinh</title>
    <meta name="keywords" content="Book Store Template, Stanford - Day lap trinh" />
    <meta name="description" content="Book Store Template, Stanford - Day lap trinh" />
    <link href="templatemo_style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<!-- Templates from www.stanford.com.vn -->
<div id="templatemo_container">
    <?php
    include_once 'layout/menu.php';
    include_once 'layout/header.php';
    ?>

    <div id="templatemo_content">

        <div id="templatemo_content_left">
             <?php
                 include_once 'layout/sidebar.php'; ?>
        </div> <!-- end of content left -->

        <div id="templatemo_content_right">
            <?php
            $i = 0;
            foreach($danhSach as $sach){?>
            <div class="templatemo_product_box">
                <h1><?php echo $sach->tenSach?><span>(by <?php echo $sach->tacGia?>)</span></h1>
                <img height="150" width="100" src="images/<?php echo $sach->anhSach?>" alt="image" />
                <div class="product_info">
                    <p><?php echo $sach->moTa?></p>
                    <h3><?php echo number_format($sach->giaSach)?></h3>
                    <div class="buy_now_button"><a href="MuaHang.php">Mua ngay</a></div>
                    <div class="detail_button"><a href="ChiTietSach.php?sachId=<?php echo $sach->sachId?>">Chi tiết</a></div>
                </div>
                <div class="cleaner">&nbsp;</div>
            </div>
            <?php if($i%2==0){?>
                <div class="cleaner_with_width">&nbsp;</div>
            <?php } else { ?>
                <div class="cleaner_with_height">&nbsp;</div>
            <?php }
            $i++;
            } ?>
            <a href="subpage.html"><img src="images/templatemo_ads.jpg" alt="ads" /></a>
        </div> <!-- end of content right -->

        <div class="cleaner_with_height">&nbsp;</div>
    </div> <!-- end of content -->

     <?php
    include_once 'layout/footer.php';
    ?>
</div> <!-- end of container -->
<div align=center>This template  downloaded form <a href='http://www.stanford.com.vn'>Stanford.com.vn</a></div></body>
</html>
