<?php

include_once 'animal.php';
class Dog extends animal
{
    public function tiengKeu()
    {
        return "Gâu gâu";
    }
}