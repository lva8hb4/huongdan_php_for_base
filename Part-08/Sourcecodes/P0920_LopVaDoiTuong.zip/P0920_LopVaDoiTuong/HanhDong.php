<?php


interface HanhDong
{
    function danhSach();
    function layChiTiet();
    function themMoi();
}