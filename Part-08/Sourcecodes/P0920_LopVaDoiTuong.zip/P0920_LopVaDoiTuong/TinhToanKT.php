<?php


class TinhToanKT
{
    private $data = "";
    private $arr = Array();
    public function __construct($data)
    {
        $this->data = $data;
        $this->chuyenVeMangSo();
    }

    /*
     * Hàm chuyển từ data dạng chuỗi ngăn cách , thành dạng mảng số
     */
    private function chuyenVeMangSo()
    {
        //Đưa chuỗi về mảng
        $arrChuoi = explode(",", $this->data);
        //Duyệt các phần tử và đưa vào mảng kiểu số
        for($i = 0; $i < count($arrChuoi); $i++)
        {
            array_push($this->arr, intval($arrChuoi[$i]));
        }
    }

    /*
     * Hàm thực hiện sắp xếp giảm dần rồi trả về chuỗi số đó
     */
    public function sapXepGiamDan()
    {
        //Sắp xếp giảm dần
        rsort($this->arr);

        $daySoGiam = implode("-", $this->arr);

        return $daySoGiam;
    }

    public $viTriMax = 0;
    public $viTriMin = 0;
    public $max = 0;
    public $min = 0;

    /*
     * Hàm tìm giá trị max, min và vị trí của chúng
     */
    public function timMaxMin()
    {
        $this->min = $this->arr[0];
        $max = $this->arr[0];
        //Duyệt từng phần tử để tìm max, min
        for($i = 0; $i < count($this->arr); $i++)
        {
            if($this->arr[$i] > $this->max)
            {
                $this->viTriMax = $i;
                $this->max = $this->arr[$i];
            }

            if($this->arr[$i] < $this->min)
            {
                $this->viTriMin = $i;
                $this->min = $this->arr[$i];
            }
        }
    }

    /**
     * Hàm thống kê số lần kí tự 5 xuất hiện
     * @return Số lượng
     */
    public function thongKeSo5()
    {
        $soLuong = 0;
        //Đưa về mảng từng kí tự
        $arrKiTu = str_split($this->data,1);

        for($i = 0; $i < count($arrKiTu); $i++)
        {
            if($arrKiTu[$i] == '5')
            {
                $soLuong++;
            }
        }

        return $soLuong;
    }

    /**
     * Hàm lấy 3 giá trị cao nhất trong dãy số
     * @return Top 3 giá trị cao nhất
     */
    public function top3GiaTriCaoNhat()
    {
        $top3 = "";
        for($i = 0; $i < 3; $i++)
        {
            $top3 .= $this->arr[$i] . "-";
        }

        $top3 = substr($top3,0, strlen($top3)-1);

        return $top3;
    }
}