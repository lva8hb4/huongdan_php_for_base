<?php


class SinhVien
{

    public $maSV;
    public $hoTen;
    public $dienThoai;
    public $email;
    public $diaChi;

    public function __construct()
    {
        $this->diaChi = "Hà Nội";
    }
}