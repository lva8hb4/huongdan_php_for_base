<?php
//Khai báo lớp
require 'SinhVienBusiness.php';

//Khai báo đối tượng
$bus = new SinhVienBusiness();

//Lấy danh sách
$danhSach = $bus->layDanhSach();
?>
<html>
<head>
    <title>Danh sách sinh viên</title>
</head>
<body>
<div style="width:100%; text-align:center;">
    <h1>Danh sách thông tin sinh viên</h1>
    <table border="1" style="width:100%; border-collapse: collapse">
        <tr>
            <th>Mã SV</th>
            <th>Họ tên</th>
            <th>Điện thoại</th>
            <th>Email</th>
            <th>Địa chỉ</th>
        </tr>
        <?php
        foreach ($danhSach as $sv){
        ?>
        <tr>
            <td><?php echo $sv->maSV?></td>
            <td><?php echo $sv->hoTen?></td>
            <td><?php echo $sv->dienThoai?></td>
            <td><?php echo $sv->email?></td>
            <td><?php echo $sv->diaChi?></td>
        </tr>
        <?php } ?>
    </table>
</div>
</body>
</html>
