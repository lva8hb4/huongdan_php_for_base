<?php
//Khai báo biến
$chuoiSo = "";
$max = 0; $min = 0; $viTriMax = 0; $viTriMin = 0;
$top3 = ""; $dayGiam = "";
$so5 = 0;

if(isset($_REQUEST['btnThucHien']))
{
    //Lấy thông tin từ trên giao diện
    $chuoiSo = $_POST['txtChuoiSo'];

    //Khai báo lớp
    require 'TinhToanKT.php';

    //Khai báo đối tượng thuộc lớp
    $tt = new TinhToanKT($chuoiSo);

    $tt->timMaxMin();

    $max = $tt->max;
    $min = $tt->min;
    $viTriMax = $tt->viTriMax;
    $viTriMin = $tt->viTriMin;
    $dayGiam = $tt->sapXepGiamDan();
    $so5 = $tt->thongKeSo5();
    $top3 = $tt->top3GiaTriCaoNhat();
}
?>
<html>
<head>
    <title>Bài kiểm tra thực hành tổng hợp
    </title>
</head>
<body>
<form method="post">
    <fieldset>
        <legend>Nhập thông tin cần tính toán</legend>
        <table>
            <tr>
                <td>
                    Chuỗi số:
                </td>
                <td>
                    <input type="text" name="txtChuoiSo" value="<?php echo $chuoiSo ?>"/>
                </td>
            </tr>
            <tr>
                <td>
                    Ví trí max:
                </td>
                <td>
                    <?php echo $viTriMax; ?>
                </td>
            </tr>
            <tr>
                <td>
                    Max:
                </td>
                <td>
                    <?php echo $max; ?>
                </td>
            </tr>
            <tr>
                <td>
                    Ví trí min:
                </td>
                <td>
                    <?php echo $viTriMin; ?>
                </td>
            </tr>
            <tr>
                <td>
                    Max:
                </td>
                <td>
                    <?php echo $min; ?>
                </td>
            </tr>
            <tr>
                <td>
                    Dãy giảm dần:
                </td>
                <td>
                    <?php echo $dayGiam; ?>
                </td>
            </tr>
            <tr>
                <td>
                    Số lượng số 5:
                </td>
                <td>
                    <?php echo $so5; ?>
                </td>
            </tr>
            <tr>
                <td>
                    Top 3:
                </td>
                <td>
                    <?php echo $top3; ?>
                </td>
            </tr>
            <tr>
                <td>

                </td>
                <td>
                    <input type="submit" name="btnThucHien" value="Thực hiện">
                </td>
            </tr>
        </table>
    </fieldset>
</form>
</body>
</html>
