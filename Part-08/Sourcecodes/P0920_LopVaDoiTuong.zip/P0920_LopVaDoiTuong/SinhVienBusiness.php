<?php
//Khai báo lớp
include_once 'SinhVien.php';

class SinhVienBusiness
{
    private $danhSach = Array();
    public function layDanhSach()
    {
        //Tạo các đối tượng sinh viên
        $chien = new SinhVien();
        $chien->maSV="SF001";
        $chien->hoTen = "Trần Anh Chiến";
        $chien->dienThoai = "0988233568";
        $chien->email="chienta@gmail.com";

        //Thêm vào danh sách
        array_push($this->danhSach, $chien);

        //Tạo các đối tượng sinh viên
        $son = new SinhVien();
        $son->maSV="SF002";
        $son->hoTen = "Nguyễn Xuân Sơn";
        $son->dienThoai = "0903233568";
        $son->email="xuanson@gmail.com";
        $son->diaChi = "Hải Dương";

        //Thêm vào danh sách
        array_push($this->danhSach, $son);

        //Tạo các đối tượng sinh viên
        $an = new SinhVien();
        $an->maSV="SF003";
        $an->hoTen = "Đỗ Trường An";
        $an->dienThoai = "0967233125";
        $an->email="xuanson@gmail.com";
        $an->diaChi = "Thái Bình";

        //Thêm vào danh sách
        array_push($this->danhSach, $an);

        return $this->danhSach;
    }

    /**
     * Hàm thêm mới sinh viên vào hệ thống
     * @param $objSV: Đối tượng sinh viên
     */
    public function themMoi($objSV)
    {
        if($objSV != null) {
            array_push($this->danhSach, $objSV);

            return true;
        }
        return false;
    }
}