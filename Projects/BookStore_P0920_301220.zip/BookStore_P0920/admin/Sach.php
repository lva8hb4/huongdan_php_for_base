<?php

//Khai báo 1 lớp để chứa các thuộc tính mô tả về sách
class Sach
{

    public $sachId;
    public $tenSach;
    public $moTa;
    public $anhSach;
    public $tacGia;
    public $ngayTao;
    public $giaSach;
    public $maChuDe;
}