<?php

$tenDangNhap = "Chưa đăng nhập";
$hoTen = "";
session_start();

//Nếu đã đăng nhập
if(isset($_SESSION['userCurrent']))
{
    $tenDangNhap = $_SESSION['userCurrent'];
    $hoTen = $_SESSION['fullName'];
}
else//Nếu chưa
{
    header("location:DangNhap.php");
    exit;
}