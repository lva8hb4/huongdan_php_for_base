<?php


class DataProvider
{
    /**
     * Hàm kết nối đến db trong mysql cần làm việc
     * @return Đối tượng kết nối
     */
    public function ketNoi()
    {
        $conn = new mysqli("localhost", "root", "Stanford", "bookstore_p0920", 3308) or die(mysqli_error());

        //Thiết lập hiển thị tiếng việt
        $conn->set_charset("utf8");

        return $conn;
    }
}