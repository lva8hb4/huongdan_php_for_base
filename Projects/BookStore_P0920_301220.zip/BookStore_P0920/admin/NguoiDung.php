<?php


class NguoiDung
{
    public $id;
    public $tenDangNhap;
    public $matKhau;
    public $hoTen;
    public $dienThoai;
    public $email;
    public $diaChi;
}