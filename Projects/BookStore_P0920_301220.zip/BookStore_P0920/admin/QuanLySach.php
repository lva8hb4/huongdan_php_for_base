<?php
//Khai báo lớp để sử dụng
include_once 'SachBusiness.php';

//Khai báo đối tượng
$bus = new SachBusiness();


//Khai báo biến
$tuKhoa = ""; $chuDe = "";

//Nếu người dùng nhấn tìm kiếm
if(isset($_REQUEST['btnTimKiem']))
{
    $tuKhoa = $_POST['txtTuKhoa'];
    $chuDe = $_POST['chuDe'];
}
//Tìm kiếm và lấy thông tin thoả mãn điều kiện
$danhSach = $bus->timKiemSach($tuKhoa, $chuDe);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta charset="utf-8" />
    <title>Tables - Ace Admin</title>

    <meta name="description" content="Static &amp; Dynamic Tables" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

    <?php
    include_once 'layout/css_library.php';
    ?>
    <![endif]-->
</head>

<body class="no-skin">
<?php
include 'KiemTraDangNhap.php';
include_once 'layout/navbar.php';
?>

<div class="main-container ace-save-state" id="main-container">
    <script type="text/javascript">
        try{ace.settings.loadState('main-container')}catch(e){}
    </script>

    <?php
    include_once 'layout/sidebar.php';
    ?>

    <div class="main-content">
        <div class="main-content-inner">
            <div class="breadcrumbs ace-save-state" id="breadcrumbs">
                <ul class="breadcrumb">
                    <li>
                        <i class="ace-icon fa fa-home home-icon"></i>
                        <a href="#">Home</a>
                    </li>

                    <li>
                        <a href="#">Tables</a>
                    </li>
                    <li class="active">Simple &amp; Dynamic</li>
                </ul><!-- /.breadcrumb -->

                <div class="nav-search" id="nav-search">
                    <form class="form-search">
								<span class="input-icon">
									<input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
									<i class="ace-icon fa fa-search nav-search-icon"></i>
								</span>
                    </form>
                </div><!-- /.nav-search -->
            </div>

            <div class="page-content">
               <div class="page-header">
                   <form method="post">
                       <fieldset>
                           <legend>Nhập thông tin tìm kiếm</legend>
                           <div class="form-group">
                               <label class="col-md-2">Từ khoá:</label>
                               <div   class="col-md-3">
                                   <input type="text" class="form-control" name="txtTuKhoa" value="<?php echo $tuKhoa?>" style="width:100%;"/>
                               </div>
                               <label  class="col-md-2">Chủ đề:</label>
                               <div   class="col-md-3">
                                   <?php
                                   //Khai báo lớp
                                   include_once 'ChuDeBusiness.php';
                                   //Khai báo đối tượng
                                   $bus = new ChuDeBusiness();

                                   $lstChuDe = $bus->layDanhSach();
                                   ?>
                                   <select class="form-control" name="chuDe">
                                       <option value="">---Chọn chủ đề---</option>
                                       <?php foreach($lstChuDe as $cd){
                                           //Nếu thông tin chủ đề trong combobox trùng với mã chủ đề của sách
                                           //thì thêm thuộc selected để chọn hiển thị thông tin đó trong combox
                                           if($cd->maChuDe == $chuDe){
                                               ?>
                                               <option selected="selected" value="<?php echo $cd->maChuDe ?>">
                                                   <?php echo $cd->tenChuDe ?>
                                               </option>
                                           <?php } else { ?>
                                               <option value="<?php echo $cd->maChuDe ?>">
                                                   <?php echo $cd->tenChuDe ?>
                                               </option>
                                           <?php }} ?>
                                   </select>
                               </div>
                               <div  class="col-md-2">
                                   <input class="btn btn-primary" type="submit" name="btnTimKiem" value="Tìm kiếm"/>
                               </div>
                           </div>
                       </fieldset>
                   </form>
               </div>
                <div class="row">
                    <div class="col-xs-12">
                        <!-- PAGE CONTENT BEGINS -->
                        <div class="row">
                            <div class="col-xs-12">
                                <h3 class="header smaller lighter blue">Danh sách thông tin sách</h3>

                                <div class="clearfix">
                                    <div class="pull-right tableTools-container"></div>
                                </div>
                                <div class="table-header">

                                </div>

                                <!-- div.table-responsive -->

                                <!-- div.dataTables_borderWrap -->
                                <div>
                                    <table id="dynamic-table" class="table table-striped table-bordered table-hover">
                                        <thead>
                                        <tr>
                                            <th>Ảnh</th>
                                            <th>Id</th>
                                            <th>Tên sách</th>
                                            <th>Mô tả</th>
                                            <th>Giá sách</th>
                                            <th>Ngày tạo</th>
                                            <th>Tác giả</th>
                                            <th></th>
                                        </tr>
                                        </thead>

                                        <tbody>
                                        <?php
                                        foreach($danhSach as $sach){ ?>
                                            <tr>
                                                <td><img src="../images/<?php echo $sach->anhSach ?>" width="80" height="80"/></td>
                                                <td><?php echo $sach->sachId ?></td>
                                                <td><?php echo $sach->tenSach ?></td>
                                                <td><?php echo $sach->moTa ?></td>
                                                <td><?php echo $sach->giaSach ?></td>
                                                <td><?php echo $sach->ngayTao ?></td>
                                                <td><?php echo $sach->tacGia ?></td>
                                                <td>
                                                    <a class="green" href="admin/SachAdd.php?sachId=<?php echo $sach->sachId?>">
                                                        <i class="ace-icon fa fa-pencil bigger-130"></i>
                                                    </a>

                                                    <a class="red" href="admin/SachAction.php?sachId=<?php echo $sach->sachId?>" onclick="return confirm('Bạn có chắc chắn muốn xoá không ?');">
                                                        <i class="ace-icon fa fa-trash-o bigger-130"></i>
                                                    </a>

                                                </td>
                                            </tr>
                                        <?php }?>

                                        </tbody>
                                        </table>
                                    </div>

                                </div><!-- /.modal-content -->
                            </div><!-- /.modal-dialog -->
                        </div>

                        <!-- PAGE CONTENT ENDS -->
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.page-content -->
        </div>
    </div><!-- /.main-content -->

    <div class="footer">
        <div class="footer-inner">
            <div class="footer-content">
						<span class="bigger-120">
							<span class="blue bolder">Stanford.com.vn</span>
							BookStore &copy; 2012-2020
						</span>

                &nbsp; &nbsp;
                <span class="action-buttons">
							<a href="#">
								<i class="ace-icon fa fa-twitter-square light-blue bigger-150"></i>
							</a>

							<a href="#">
								<i class="ace-icon fa fa-facebook-square text-primary bigger-150"></i>
							</a>

							<a href="#">
								<i class="ace-icon fa fa-rss-square orange bigger-150"></i>
							</a>
						</span>
            </div>
        </div>
    </div>

    <a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
        <i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
    </a>
</div><!-- /.main-container -->

<!-- basic scripts -->

<!--[if !IE]> -->
<?php
include_once 'layout/js_library.php';
?>
</body>
</html>
