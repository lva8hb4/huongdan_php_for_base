<?php
include_once 'DataProvider.php';
include_once 'NguoiDung.php';

class NguoiDungBusiness extends DataProvider
{

    public function kiemTraTenDangNhap($tenDangNhap)
    {
        //Khai báo 1 doi tuong chua thong tin nguoi dung
        $objNguoiDung = null;

        //Lấy đối tượng kết nối đến db
        $conn = $this->ketNoi();

        //Khai báo câu lệnh truy vấn để lấy thông tin
        $strSQL = "Select Id, TenDangNhap, MatKhau, HoTen from NguoiDung 
where TenDangNhap='" . $tenDangNhap . "'";
        //Lấy danh sách chủ đề từ db
        $ketQua = mysqli_query($conn, $strSQL);

        //Đọc từng dòng để đưa vào danh sách
        while($row = mysqli_fetch_array($ketQua))
        {
            //Khai báo 1 đối tượng sách
            $objNguoiDung = new NguoiDung();
            $objNguoiDung->id = $row['Id'];
            $objNguoiDung->tenDangNhap = $row['TenDangNhap'];
            $objNguoiDung->matKhau = $row['MatKhau'];
            $objNguoiDung->hoTen = $row['HoTen'];
        }

        //Đóng kết nối
        $conn->close();

        return $objNguoiDung;
    }//End nguoi dung
}