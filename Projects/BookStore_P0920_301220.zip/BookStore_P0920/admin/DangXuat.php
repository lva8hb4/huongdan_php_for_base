<?php
session_start();
//Xoá session đi
session_destroy();
//Di chuyển về trang đăng nhập
header("location:DangNhap.php");
exit;
