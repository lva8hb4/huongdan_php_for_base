<?php

if(isset($_REQUEST['sachId']))
{
    $maSach = intval($_GET['sachId']);
    //Khai báo lớp
    include_once 'SachBusiness.php';

    $bus = new SachBusiness();

    //Gọi hàm thực hiện xoá
    $kq = $bus->xoa($maSach);

    if($kq)
    {
        //Sau khi xoá thành công thi trở lại danh sách
        header("location:QuanLySach.php");
    }
}