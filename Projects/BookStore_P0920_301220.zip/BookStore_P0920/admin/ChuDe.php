<?php


class ChuDe
{
    public $maChuDe;
    public $tenChuDe;
    public $moTa;
}