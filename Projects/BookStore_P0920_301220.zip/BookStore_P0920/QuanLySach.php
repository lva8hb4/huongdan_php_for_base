<?php
//Khai báo lớp để sử dụng
include_once 'SachBusiness.php';

//Khai báo đối tượng
$bus = new SachBusiness();


//Khai báo biến
$tuKhoa = ""; $chuDe = "";

//Nếu người dùng nhấn tìm kiếm
if(isset($_REQUEST['btnTimKiem']))
{
    $tuKhoa = $_POST['txtTuKhoa'];
    $chuDe = $_POST['chuDe'];
}
//Tìm kiếm và lấy thông tin thoả mãn điều kiện
$danhSach = $bus->timKiemSach($tuKhoa, $chuDe);

?>
<html>
<head>
    <title>Quản lý thông tin sách</title>
</head>
<body>
<div style="width:100%; text-align:center;">
    <h1>Quản lý thông tin sách</h1>
</div>
<form method="post">
<fieldset>
    <legend>Nhập thông tin tìm kiếm</legend>
    <div style="width:100%; display:block;">
        <label style="float:left;">Từ khoá:</label>
        <div  style="float:left; width:30%;">
            <input type="text" name="txtTuKhoa" value="<?php echo $tuKhoa?>" style="width:100%;"/>
        </div>
        <label  style="float:left;padding-left:10px;">Chủ đề:</label>
        <div  style="float:left;width:30%;">
            <?php
            //Khai báo lớp
            include_once 'ChuDeBusiness.php';
            //Khai báo đối tượng
            $bus = new ChuDeBusiness();

            $lstChuDe = $bus->layDanhSach();
            ?>
            <select name="chuDe">
                <option value="">---Chọn chủ đề---</option>
                <?php foreach($lstChuDe as $cd){
                    //Nếu thông tin chủ đề trong combobox trùng với mã chủ đề của sách
                    //thì thêm thuộc selected để chọn hiển thị thông tin đó trong combox
                    if($cd->maChuDe == $chuDe){
                        ?>
                        <option selected="selected" value="<?php echo $cd->maChuDe ?>">
                            <?php echo $cd->tenChuDe ?>
                        </option>
                    <?php } else { ?>
                        <option value="<?php echo $cd->maChuDe ?>">
                            <?php echo $cd->tenChuDe ?>
                        </option>
                    <?php }} ?>
            </select>
        </div>
        <div  style="float:left;padding-left:10px;">
            <input type="submit" name="btnTimKiem" value="Tìm kiếm"/>
        </div>
    </div>
</fieldset>
</form>
<div style="width:100%; text-align:right;">
    <a href="admin/SachAdd.php">Thêm mới</a>
</div>
<table border="1" style="width:100%; border-collapse: collapse;">
    <tr>
        <th>Ảnh</th>
        <th>Id</th>
        <th>Tên sách</th>
        <th>Mô tả</th>
        <th>Giá sách</th>
        <th>Ngày tạo</th>
        <th>Tác giả</th>
        <th></th>
    </tr>
    <?php
        foreach($danhSach as $sach){ ?>
    <tr>
        <td><?php echo $sach->anhSach ?></td>
        <td><?php echo $sach->sachId ?></td>
        <td><?php echo $sach->tenSach ?></td>
        <td><?php echo $sach->moTa ?></td>
        <td><?php echo $sach->giaSach ?></td>
        <td><?php echo $sach->ngayTao ?></td>
        <td><?php echo $sach->tacGia ?></td>
        <td>
            <a href="admin/SachAdd.php?sachId=<?php echo $sach->sachId?>">Sửa</a>
            &nbsp;
            <a href="admin/SachAction.php?sachId=<?php echo $sach->sachId?>" onclick="return confirm('Bạn có chắc chắn muốn xoá không ?');">Xoá</a>
        </td>
    </tr>
    <?php }?>
</table>
</body>
</html>
