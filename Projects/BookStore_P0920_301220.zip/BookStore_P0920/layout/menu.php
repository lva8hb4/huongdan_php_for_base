<div id="templatemo_menu">
    <ul>
        <li><a href="TrangChu.php" class="current">Trang chủ</a></li>
        <li><a href="subpage.html">Tìm kiếm</a></li>
        <li><a href="subpage.html">Sách</a></li>
        <li><a href="subpage.html">Sách mới</a></li>
        <li><a href="#">Giới thiệu</a></li>
        <li><a href="#">Liên hệ</a></li>
    </ul>
</div> <!-- end of menu -->