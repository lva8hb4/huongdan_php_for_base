Cufon.replace('h2, .font2, h3, .call1', { fontFamily: 'Molengo', hover:true });
Cufon.replace('#menu a, #slogan, .font1, .call2', { fontFamily: 'Expletus Sans', hover:true });
Cufon.replace('.date', { fontFamily: 'Expletus Sans', hover:true, color: '-linear-gradient(#747474, #595959, #383838)' });

